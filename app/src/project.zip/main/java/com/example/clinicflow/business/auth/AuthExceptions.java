package com.example.clinicflow.business.auth;

public class AuthExceptions {

    public static class AuthException extends Exception {
        public AuthException(String message) {
            super(message);
        }
    }

    public static class InvalidInputException extends AuthException {
        public InvalidInputException(String message) {
            super(message);
        }
    }

    public static class UserNotFoundException extends AuthException {
        public UserNotFoundException(String message) {
            super(message);
        }
    }

    public static class WrongPasswordException extends AuthException {
        public WrongPasswordException(String message) {
            super(message);
        }
    }
}