package com.example.clinicflow.presentation.sharedScreens;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.clinicflow.application.ClinicFlowApp;
import com.example.clinicflow.R;
import com.example.clinicflow.models.Patient;
import com.example.clinicflow.persistence.UserRepository;
import com.example.clinicflow.presentation.authScreens.MainActivity;
import com.example.clinicflow.presentation.staffScreens.StaffProfile;
import com.google.android.material.card.MaterialCardView;

public class ViewPatients extends AppCompatActivity{

    public static final String EXTRA_PATIENT_EMAIL = "patient_email";
    private MaterialCardView patientCard;
    private ImageButton profile;
    private Button back;
    private Button search;
    private Button viewRecords;
    private EditText emailAddress;
    private TextView email;
    private TextView name;
    private TextView gender;
    private TextView age;
    private TextView hc;
    private TextView phone;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.view_patients);

        ClinicFlowApp app = (ClinicFlowApp) getApplication();
        UserRepository userRepository = app.getUserRepository();

        setViews();

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredEmail = emailAddress.getText().toString().trim();

                Patient patient = userRepository.getPatientByEmail(enteredEmail);

                if (patient == null) {
                    Toast.makeText(getApplicationContext(), "No Such Account", Toast.LENGTH_LONG).show();
                    viewRecords.setVisibility(View.INVISIBLE);
                    patientCard.setVisibility(View.INVISIBLE);
                } else {
                    email.setText(patient.getEmail());
                    name.setText(patient.getFullName());
                    gender.setText(patient.getGender());
                    age.setText(String.valueOf(patient.getAge()));
                    hc.setText(String.valueOf(patient.getHealthCardNumber()));
                    phone.setText(String.valueOf(patient.getPhoneNumber()));

                    viewRecords.setVisibility(View.VISIBLE);
                    patientCard.setVisibility(View.VISIBLE);
                }
            }
        });

        viewRecords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewPatients.this, MyRecords.class);
                intent.putExtra(EXTRA_PATIENT_EMAIL, emailAddress.getText().toString().trim());
                intent.putExtra(MainActivity.EXTRA_USER_EMAIL, getIntent().getStringExtra(MainActivity.EXTRA_USER_EMAIL));
                startActivity(intent);
            }
        });


        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewPatients.this, StaffProfile.class);
                intent.putExtra(MainActivity.EXTRA_USER_EMAIL, getIntent().getStringExtra(MainActivity.EXTRA_USER_EMAIL));
                startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void setViews() {
        patientCard = findViewById(R.id.patientCard);
        viewRecords = findViewById(R.id.viewRecordsButton);
        search = findViewById(R.id.searchButton);
        profile = findViewById(R.id.profileButton);
        back = findViewById(R.id.backButton);

        email = findViewById(R.id.emailActual);
        name = findViewById(R.id.nameActual);
        gender = findViewById(R.id.genderActual);
        age = findViewById(R.id.ageActual);
        hc = findViewById(R.id.healthCardActual);
        phone = findViewById(R.id.phoneActual);

        emailAddress = findViewById(R.id.editTextEmailAddress);
    }
}
