package com.example.clinicflow.persistence;

import com.example.clinicflow.models.Doctor;
import com.example.clinicflow.models.MedicalRecord;
import com.example.clinicflow.models.Patient;
import com.example.clinicflow.models.Staff;

import java.util.List;
//User repository
public interface UserRepository {
    List<Patient> getAllPatients();

    List<Doctor> getAllDoctors();

    List<Staff> getAllStaffs();

    void addPatient(Patient patient);

    Patient getPatientByEmail(String email);

    List<MedicalRecord> getMedicalRecords(String patientEmail);

    void addMedicalRecord(MedicalRecord record);

}
